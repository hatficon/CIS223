def main():
    l = ["Apples", "Cookies", "Ice Cream", "Steak"]
    for food in l:
        print(food)


main()
