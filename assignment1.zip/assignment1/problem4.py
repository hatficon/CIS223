def main():
    noun = input("Enter a noun: ")
    verb = input("Enter a verb: ")
    adjective = input("Enter an adjective: ")
    place = input("Enter a place: ")
    print("Take your " + adjective + " " + noun + " and " + verb + " it at the " + place + "!")


main()