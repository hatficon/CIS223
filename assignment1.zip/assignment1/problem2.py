def main():
    firstName = input("What is your first name?")
    lastName = input("What is your last name?")
    print("Hello, " + firstName + " " + lastName + "!")


main()