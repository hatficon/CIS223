import math
def main():
    speedOfLight = 186000
    distance = 34000000
    time = distance/speedOfLight
    print(str(time/60) + " minutes.")


main()